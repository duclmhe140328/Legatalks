import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';

const projectRoot = path.resolve(process.argv[2]);
const configFile = path.resolve(process.argv[3]);
const patchRoot = path.resolve(process.argv[4]);

function fail(message) {
  console.error(`ERROR: ${message}`);
  process.exit(1);
}

function backup(file, suffix) {
  if (!fs.existsSync(file)) return;
  const backupFile = `${file}.${suffix}`;
  if (!fs.existsSync(backupFile)) {
    fs.copyFileSync(file, backupFile);
    console.log(`Backup: ${backupFile}`);
  }
}

function copyFile(relativePath) {
  const source = path.join(patchRoot, relativePath);
  const destination = path.join(projectRoot, relativePath);
  if (!fs.existsSync(source)) fail(`Patch source not found: ${source}`);
  fs.mkdirSync(path.dirname(destination), { recursive: true });
  backup(destination, 'bak_before_jwt_jitsi_sync');
  fs.copyFileSync(source, destination);
  console.log(`Installed: ${destination}`);
}

function setEnvValue(lines, name, value) {
  const prefix = `${name}=`;
  let found = false;
  const next = lines.map((line) => {
    if (line.startsWith(prefix)) {
      found = true;
      return `${name}=${value}`;
    }
    return line;
  });
  if (!found) next.push(`${name}=${value}`);
  return next;
}

function removeEnvNames(lines, names) {
  const prefixes = names.map((name) => `${name}=`);
  return lines.filter((line) => !prefixes.some((prefix) => line.startsWith(prefix)));
}

function patchIndex() {
  const file = path.join(projectRoot, 'apps/server/src/index.js');
  if (!fs.existsSync(file)) fail(`Server index not found: ${file}`);
  backup(file, 'bak_before_jwt_jitsi_sync');
  let text = fs.readFileSync(file, 'utf8');

  if (!text.includes("from './routes/jitsi.js'")) {
    const routeImportRegex =
      /(^import\s+.+?Routes\s+from\s+['"].+?routes\/.+?['"];\s*$)/gm;
    const imports = [...text.matchAll(routeImportRegex)];
    if (imports.length > 0) {
      const last = imports.at(-1);
      const insertAt = last.index + last[0].length;
      text =
        text.slice(0, insertAt) +
        "\nimport jitsiRoutes from './routes/jitsi.js';" +
        text.slice(insertAt);
    } else {
      text = "import jitsiRoutes from './routes/jitsi.js';\n" + text;
    }
  }

  if (!text.includes("app.use('/api/jitsi'")) {
    const anchor =
      text.indexOf("app.use('/api/meetings'") >= 0
        ? "app.use('/api/meetings'"
        : "app.use('/api/auth'";
    const start = text.indexOf(anchor);
    if (start < 0) fail('Could not locate an app.use route anchor in apps/server/src/index.js');
    const end = text.indexOf('\n', start);
    text =
      text.slice(0, end + 1) +
      "app.use('/api/jitsi', jitsiRoutes);\n" +
      text.slice(end + 1);
  }

  fs.writeFileSync(file, text, 'utf8');
  console.log(`Patched: ${file}`);
}

function patchEnv(config) {
  const serverEnv = path.join(projectRoot, 'apps/server/.env');
  const webEnv = path.join(projectRoot, 'apps/web/.env');
  backup(serverEnv, 'bak_before_jwt_jitsi_sync');
  backup(webEnv, 'bak_before_jwt_jitsi_sync');

  let serverLines = fs.existsSync(serverEnv)
    ? fs.readFileSync(serverEnv, 'utf8').split(/\r?\n/)
    : [];

  const pairs = {
    JWT_ACCESS_SECRET: config.jwtAccessSecret,
    JWT_REFRESH_SECRET: config.jwtRefreshSecret,
    JITSI_APP_ID: config.jitsiAppId,
    JITSI_APP_SECRET: config.jitsiAppSecret,
    JITSI_DOMAIN: config.jitsiDomain,
    JITSI_SERVER_URL: config.jitsiServerUrl,
    JITSI_TOKEN_TTL_SECONDS: String(config.jitsiTokenTtlSeconds),
  };

  for (const [name, value] of Object.entries(pairs)) {
    serverLines = setEnvValue(serverLines, name, value);
  }

  fs.mkdirSync(path.dirname(serverEnv), { recursive: true });
  fs.writeFileSync(
    serverEnv,
    serverLines.filter((line, index, all) => {
      if (line !== '') return true;
      return index === 0 || all[index - 1] !== '';
    }).join('\n').trimEnd() + '\n',
    'utf8',
  );

  let webLines = fs.existsSync(webEnv)
    ? fs.readFileSync(webEnv, 'utf8').split(/\r?\n/)
    : [];

  webLines = removeEnvNames(webLines, [
    'JWT_ACCESS_SECRET',
    'JWT_REFRESH_SECRET',
    'JITSI_APP_SECRET',
    'VITE_JITSI_APP_SECRET',
    'JITSI_APP_ID',
    'VITE_JITSI_APP_ID',
    'VITE_JITSI_SERVER_URL',
  ]);

  webLines.push(`VITE_JITSI_SERVER_URL=${config.jitsiServerUrl}`);
  fs.mkdirSync(path.dirname(webEnv), { recursive: true });
  fs.writeFileSync(webEnv, webLines.filter(Boolean).join('\n').trimEnd() + '\n', 'utf8');

  const output = [
    `JWT_ACCESS_SECRET=${config.jwtAccessSecret}`,
    `JWT_REFRESH_SECRET=${config.jwtRefreshSecret}`,
    '',
    `JITSI_APP_ID=${config.jitsiAppId}`,
    `JITSI_APP_SECRET=${config.jitsiAppSecret}`,
    `JITSI_DOMAIN=${config.jitsiDomain}`,
    `JITSI_SERVER_URL=${config.jitsiServerUrl}`,
    `JITSI_TOKEN_TTL_SECONDS=${config.jitsiTokenTtlSeconds}`,
    '',
  ].join('\n');

  fs.writeFileSync(path.join(projectRoot, 'RENDER_ENV_VALUES.txt'), output, 'utf8');
  fs.writeFileSync(
    path.join(projectRoot, 'JITSI_SERVER_VALUES.env'),
    [
      `JITSI_HOST=${config.jitsiDomain}`,
      `JITSI_APP_ID=${config.jitsiAppId}`,
      `JITSI_APP_SECRET=${config.jitsiAppSecret}`,
      `JITSI_ALLOW_GUESTS=0`,
      '',
    ].join('\n'),
    'utf8',
  );

  const fingerprints = {};
  for (const [name, value] of Object.entries({
    JWT_ACCESS_SECRET: config.jwtAccessSecret,
    JWT_REFRESH_SECRET: config.jwtRefreshSecret,
    JITSI_APP_SECRET: config.jitsiAppSecret,
  })) {
    fingerprints[name] = {
      length: value.length,
      sha256_12: crypto.createHash('sha256').update(value).digest('hex').slice(0, 12),
    };
  }
  fs.writeFileSync(
    path.join(projectRoot, 'JWT_JITSI_FINGERPRINTS.json'),
    JSON.stringify(fingerprints, null, 2) + '\n',
    'utf8',
  );

  console.log(`Updated: ${serverEnv}`);
  console.log(`Updated: ${webEnv}`);
  console.log(`Created: ${path.join(projectRoot, 'RENDER_ENV_VALUES.txt')}`);
  console.log(`Created: ${path.join(projectRoot, 'JITSI_SERVER_VALUES.env')}`);
  console.log(`Created: ${path.join(projectRoot, 'JWT_JITSI_FINGERPRINTS.json')}`);
}

if (!projectRoot || !fs.existsSync(projectRoot)) fail(`Project root not found: ${projectRoot}`);
if (!fs.existsSync(configFile)) fail(`Generated setup config not found: ${configFile}`);
const config = JSON.parse(fs.readFileSync(configFile, 'utf8'));

copyFile('apps/server/src/services/jitsiToken.js');
copyFile('apps/server/src/routes/jitsi.js');
patchIndex();
patchEnv(config);
console.log('');
console.log('LOCAL JWT/JITSI PATCH COMPLETE.');
