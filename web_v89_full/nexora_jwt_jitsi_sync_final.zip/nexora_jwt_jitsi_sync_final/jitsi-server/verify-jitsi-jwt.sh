#!/usr/bin/env bash
set -euo pipefail

HOST="${1:-42.96.12.227}"

echo "Checking HTTPS asset..."
curl -fsSI "https://${HOST}/external_api.js" | head

echo
echo "Checking services..."
systemctl is-active prosody
systemctl is-active jicofo
systemctl is-active jitsi-videobridge2
systemctl is-active nginx

echo
echo "Checking Prosody token settings..."
grep -nE 'authentication\s*=\s*"token"|app_id|app_secret|allow_empty_token|token_verification' \
  "/etc/prosody/conf.avail/${HOST}.cfg.lua" \
  | sed -E 's/(app_secret\s*=\s*").*(")/\1***HIDDEN***\2/'
