#!/usr/bin/env bash
set -euo pipefail

ENV_FILE="${1:-/root/nexora-jitsi.env}"

if [[ "${EUID}" -ne 0 ]]; then
  echo "Run as root: sudo bash $0 ${ENV_FILE}"
  exit 1
fi

if [[ ! -f "${ENV_FILE}" ]]; then
  echo "Missing env file: ${ENV_FILE}"
  exit 1
fi

set -a
source "${ENV_FILE}"
set +a

: "${JITSI_HOST:?Missing JITSI_HOST}"
: "${JITSI_APP_ID:?Missing JITSI_APP_ID}"
: "${JITSI_APP_SECRET:?Missing JITSI_APP_SECRET}"

JITSI_ALLOW_GUESTS="${JITSI_ALLOW_GUESTS:-0}"
PROSODY_FILE="/etc/prosody/conf.avail/${JITSI_HOST}.cfg.lua"
MEET_CONFIG="/etc/jitsi/meet/${JITSI_HOST}-config.js"
STAMP="$(date +%Y%m%d_%H%M%S)"

if [[ ! -f "${PROSODY_FILE}" ]]; then
  echo "Prosody config not found: ${PROSODY_FILE}"
  ls -1 /etc/prosody/conf.avail/*.cfg.lua 2>/dev/null || true
  exit 1
fi

if [[ ! -f "${MEET_CONFIG}" ]]; then
  echo "Jitsi config not found: ${MEET_CONFIG}"
  ls -1 /etc/jitsi/meet/*-config.js 2>/dev/null || true
  exit 1
fi

echo "[1/7] Installing token modules..."
apt-get update
DEBIAN_FRONTEND=noninteractive apt-get install -y jitsi-meet-tokens

echo "[2/7] Backing up configuration..."
cp "${PROSODY_FILE}" "${PROSODY_FILE}.bak_${STAMP}"
cp "${MEET_CONFIG}" "${MEET_CONFIG}.bak_${STAMP}"
cp /etc/jitsi/jicofo/jicofo.conf "/etc/jitsi/jicofo/jicofo.conf.bak_${STAMP}" 2>/dev/null || true

echo "[3/7] Patching Prosody..."
python3 - "${PROSODY_FILE}" "${JITSI_HOST}" "${JITSI_APP_ID}" "${JITSI_APP_SECRET}" "${JITSI_ALLOW_GUESTS}" <<'PY'
import pathlib
import re
import sys

file_path = pathlib.Path(sys.argv[1])
host = sys.argv[2]
app_id = sys.argv[3]
app_secret = sys.argv[4]
allow_guests = sys.argv[5] == "1"

lines = file_path.read_text(encoding="utf-8").splitlines()

def block_end(start):
    for index in range(start + 1, len(lines)):
        if re.match(r'^(VirtualHost|Component)\s+"', lines[index]):
            return index
    return len(lines)

virtual_header = f'VirtualHost "{host}"'
virtual_start = next((i for i, line in enumerate(lines) if line.strip() == virtual_header), None)
if virtual_start is None:
    raise SystemExit(f"VirtualHost not found: {virtual_header}")

virtual_end = block_end(virtual_start)
virtual_body = lines[virtual_start + 1:virtual_end]
remove_keys = ("authentication", "app_id", "app_secret", "allow_empty_token")
virtual_body = [
    line for line in virtual_body
    if not any(re.match(rf'^\s*{re.escape(key)}\s*=', line) for key in remove_keys)
]

new_auth = [
    '    authentication = "token"',
    f'    app_id = "{app_id}"',
    f'    app_secret = "{app_secret}"',
    '    allow_empty_token = false',
]

lines = lines[:virtual_start + 1] + new_auth + virtual_body + lines[virtual_end:]

conference_header = f'Component "conference.{host}" "muc"'
conf_start = next((i for i, line in enumerate(lines) if line.strip() == conference_header), None)
if conf_start is None:
    raise SystemExit(f"Conference component not found: {conference_header}")

conf_end = block_end(conf_start)
conf_lines = lines[conf_start + 1:conf_end]

if not any('"token_verification"' in line or "'token_verification'" in line for line in conf_lines):
    modules_start = None
    modules_end = None

    for offset, line in enumerate(conf_lines):
        if re.match(r'^\s*modules_enabled\s*=\s*\{', line):
            modules_start = offset
            depth = line.count("{") - line.count("}")
            for end_offset in range(offset + 1, len(conf_lines)):
                depth += conf_lines[end_offset].count("{") - conf_lines[end_offset].count("}")
                if depth <= 0:
                    modules_end = end_offset
                    break
            break

    if modules_start is not None and modules_end is not None:
        conf_lines.insert(modules_end, '        "token_verification";')
    else:
        conf_lines = [
            '    modules_enabled = {',
            '        "token_verification";',
            '    };',
        ] + conf_lines

lines = lines[:conf_start + 1] + conf_lines + lines[conf_end:]

guest_header = f'VirtualHost "guest.{host}"'
guest_exists = any(line.strip() == guest_header for line in lines)

if allow_guests and not guest_exists:
    insert_at = block_end(virtual_start)
    guest_block = [
        '',
        guest_header,
        '    authentication = "jitsi-anonymous"',
        '    c2s_require_encryption = false',
        '',
    ]
    lines = lines[:insert_at] + guest_block + lines[insert_at:]

if not allow_guests and guest_exists:
    guest_start = next(i for i, line in enumerate(lines) if line.strip() == guest_header)
    guest_end = block_end(guest_start)
    lines = lines[:guest_start] + lines[guest_end:]

file_path.write_text("\n".join(lines).rstrip() + "\n", encoding="utf-8")
PY

echo "[4/7] Patching Jitsi Meet config..."
python3 - "${MEET_CONFIG}" "${JITSI_HOST}" "${JITSI_ALLOW_GUESTS}" <<'PY'
import pathlib
import re
import sys

file_path = pathlib.Path(sys.argv[1])
host = sys.argv[2]
allow_guests = sys.argv[3] == "1"
text = file_path.read_text(encoding="utf-8")

text = re.sub(
    r'^\s*anonymousdomain\s*:\s*[\'"][^\'"]+[\'"]\s*,?\s*$',
    '',
    text,
    flags=re.MULTILINE,
)

if allow_guests:
    hosts_match = re.search(r'hosts\s*:\s*\{', text)
    if not hosts_match:
        raise SystemExit("Could not find hosts: { in Jitsi config")
    insert_at = hosts_match.end()
    text = text[:insert_at] + f"\n        anonymousdomain: 'guest.{host}'," + text[insert_at:]

file_path.write_text(text, encoding="utf-8")
PY

echo "[5/7] Verifying Jicofo auth is not enabled..."
if [[ -f /etc/jitsi/jicofo/jicofo.conf ]]; then
  if grep -Eq 'authentication\s*\{[^}]*enabled\s*=\s*true' /etc/jitsi/jicofo/jicofo.conf; then
    echo "WARNING: jicofo.conf appears to enable old authentication."
    exit 1
  fi
fi

echo "[6/7] Checking configuration..."
prosodyctl check config
nginx -t

echo "[7/7] Restarting services..."
systemctl restart prosody
systemctl restart jicofo
systemctl restart jitsi-videobridge2
systemctl restart nginx

echo
echo "JITSI JWT CONFIGURATION COMPLETE."
echo "Host: ${JITSI_HOST}"
echo "App ID: ${JITSI_APP_ID}"
echo "Guests allowed: ${JITSI_ALLOW_GUESTS}"
