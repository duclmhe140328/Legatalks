param(
  [string]$ProjectRoot = "D:\fullweb\web_v89_full\web_v89_full_FIXED"
)

$ErrorActionPreference = "Stop"

function Get-EnvMap {
  param([string]$File)
  $map = @{}
  if (!(Test-Path -LiteralPath $File)) { return $map }

  foreach ($line in Get-Content -LiteralPath $File) {
    if ($line -match '^\s*#' -or $line -notmatch '=') { continue }
    $parts = $line -split '=', 2
    $map[$parts[0].Trim()] = $parts[1]
  }

  return $map
}

function Is-UsableSecret {
  param([string]$Value)
  if ([string]::IsNullOrWhiteSpace($Value)) { return $false }
  if ($Value.Length -lt 32) { return $false }
  return $Value -notmatch 'replace|change|dev-|your-|secret-here|^\.+$'
}

function New-Secret {
  return node -e "console.log(require('crypto').randomBytes(64).toString('hex'))"
}

function Ask-YesNo {
  param([string]$Message, [bool]$DefaultYes = $true)
  $suffix = if ($DefaultYes) { "[Y/n]" } else { "[y/N]" }
  $answer = Read-Host "$Message $suffix"
  if ([string]::IsNullOrWhiteSpace($answer)) { return $DefaultYes }
  return $answer.Trim().ToLowerInvariant().StartsWith("y")
}

if (!(Test-Path -LiteralPath $ProjectRoot)) {
  throw "Project root not found: $ProjectRoot"
}

if (!(Get-Command node -ErrorAction SilentlyContinue)) {
  throw "Node.js was not found in PATH."
}

$ServerEnv = Join-Path $ProjectRoot "apps\server\.env"
$Current = Get-EnvMap -File $ServerEnv

$AccessSecret = [string]$Current["JWT_ACCESS_SECRET"]
$RefreshSecret = [string]$Current["JWT_REFRESH_SECRET"]
$JitsiSecret = [string]$Current["JITSI_APP_SECRET"]
$JitsiAppId = [string]$Current["JITSI_APP_ID"]
$JitsiDomain = [string]$Current["JITSI_DOMAIN"]
$JitsiServerUrl = [string]$Current["JITSI_SERVER_URL"]

if ([string]::IsNullOrWhiteSpace($JitsiAppId)) { $JitsiAppId = "nexora" }
if ([string]::IsNullOrWhiteSpace($JitsiDomain)) { $JitsiDomain = "42.96.12.227" }
if ([string]::IsNullOrWhiteSpace($JitsiServerUrl)) { $JitsiServerUrl = "https://$JitsiDomain" }

Write-Host ""
Write-Host "NEXORA JWT + JITSI SYNC"
Write-Host "Project: $ProjectRoot"
Write-Host ""

if ((Is-UsableSecret $AccessSecret) -and (Is-UsableSecret $RefreshSecret)) {
  $KeepLogin = Ask-YesNo `
    -Message "Keep the current access/refresh login secrets? Choose Y if login currently works." `
    -DefaultYes $true

  if (-not $KeepLogin) {
    $AccessSecret = New-Secret
    $RefreshSecret = New-Secret
    Write-Host "Generated new login secrets. Existing web/mobile login tokens must be cleared."
  }
} else {
  $AccessSecret = New-Secret
  $RefreshSecret = New-Secret
  Write-Host "Generated missing or unsafe login secrets."
}

if (Is-UsableSecret $JitsiSecret) {
  $KeepJitsi = Ask-YesNo `
    -Message "Keep the current JITSI_APP_SECRET? Choose Y if meetings currently work." `
    -DefaultYes $true

  if (-not $KeepJitsi) {
    $JitsiSecret = New-Secret
    Write-Host "Generated a new Jitsi secret. Update the Jitsi VPS with the generated value."
  }
} else {
  $JitsiSecret = New-Secret
  Write-Host "Generated a missing or unsafe Jitsi secret. Update the Jitsi VPS."
}

$InputHost = Read-Host "Jitsi host without https:// [$JitsiDomain]"
if (![string]::IsNullOrWhiteSpace($InputHost)) { $JitsiDomain = $InputHost.Trim() }

$InputAppId = Read-Host "Jitsi Application ID [$JitsiAppId]"
if (![string]::IsNullOrWhiteSpace($InputAppId)) { $JitsiAppId = $InputAppId.Trim() }

$JitsiServerUrl = "https://$JitsiDomain"

$Config = @{
  jwtAccessSecret = $AccessSecret
  jwtRefreshSecret = $RefreshSecret
  jitsiAppId = $JitsiAppId
  jitsiAppSecret = $JitsiSecret
  jitsiDomain = $JitsiDomain
  jitsiServerUrl = $JitsiServerUrl
  jitsiTokenTtlSeconds = 3600
}

$TempConfig = Join-Path $env:TEMP "nexora-jwt-jitsi-setup.json"
$Utf8NoBom = New-Object System.Text.UTF8Encoding($false)

[System.IO.File]::WriteAllText(
  $TempConfig,
  ($Config | ConvertTo-Json -Depth 10),
  $Utf8NoBom
)

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$PatchScript = Join-Path $ScriptDir "tools\patch-project.mjs"

node $PatchScript $ProjectRoot $TempConfig $ScriptDir

if ($LASTEXITCODE -ne 0) {
  throw "Patch failed with exit code $LASTEXITCODE"
}

Remove-Item $TempConfig -Force -ErrorAction SilentlyContinue

Write-Host ""
Write-Host "DONE."
Write-Host "Important files:"
Write-Host "  $ProjectRoot\RENDER_ENV_VALUES.txt"
Write-Host "  $ProjectRoot\JITSI_SERVER_VALUES.env"
Write-Host "  $ProjectRoot\JWT_JITSI_FINGERPRINTS.json"
Write-Host "Do not upload these files to GitHub."
