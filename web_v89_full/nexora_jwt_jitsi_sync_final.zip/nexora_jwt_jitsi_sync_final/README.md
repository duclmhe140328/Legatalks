# Nexora JWT + Jitsi Sync Final

Gói này tự sửa backend JWT/Jitsi, tự gộp biến môi trường và tạo file để điền vào VPS/Render.

## Chạy local

```powershell
cd D:\fullweb\web_v89_full\nexora_jwt_jitsi_sync_final

powershell -ExecutionPolicy Bypass `
  -File .\setup-local-jwt-jitsi.ps1 `
  -ProjectRoot D:\fullweb\web_v89_full\web_v89_full_FIXED
```

Nếu project thật nằm trực tiếp tại `D:\fullweb\web_v89_full`, đổi ProjectRoot tương ứng.

### Trả lời câu hỏi

- `Keep the current access/refresh login secrets?`:
  - Chọn `Y` nếu login đang chạy.
  - Chọn `N` nếu muốn xoay lại access/refresh secret. Sau đó phải xóa phiên web/mobile.

- `Keep the current JITSI_APP_SECRET?`:
  - Chọn `Y` nếu họp vừa redo xong và đang vào được.
  - Đây là lựa chọn khuyến nghị cho tình trạng hiện tại.

- `Jitsi host without https://`:
  - Điền `42.96.12.227`.

- `Jitsi Application ID`:
  - Điền `nexora`.

Sau khi chạy sẽ có:

```text
RENDER_ENV_VALUES.txt
JITSI_SERVER_VALUES.env
JWT_JITSI_FINGERPRINTS.json
```

Không push ba file này lên GitHub.

## Cập nhật VPS Jitsi

SSH port 22:

```powershell
scp D:\fullweb\web_v89_full\web_v89_full_FIXED\JITSI_SERVER_VALUES.env root@42.96.12.227:/root/nexora-jitsi.env

scp D:\fullweb\web_v89_full\nexora_jwt_jitsi_sync_final\jitsi-server\apply-jitsi-jwt.sh root@42.96.12.227:/root/apply-jitsi-jwt.sh
```

SSH port 26266:

```powershell
scp -P 26266 D:\fullweb\web_v89_full\web_v89_full_FIXED\JITSI_SERVER_VALUES.env root@42.96.12.227:/root/nexora-jitsi.env

scp -P 26266 D:\fullweb\web_v89_full\nexora_jwt_jitsi_sync_final\jitsi-server\apply-jitsi-jwt.sh root@42.96.12.227:/root/apply-jitsi-jwt.sh
```

Vào VPS:

```powershell
ssh root@42.96.12.227
```

hoặc:

```powershell
ssh -p 26266 root@42.96.12.227
```

Chạy:

```bash
chmod 600 /root/nexora-jitsi.env
chmod +x /root/apply-jitsi-jwt.sh
sudo bash /root/apply-jitsi-jwt.sh /root/nexora-jitsi.env
```

## Render

Mở `RENDER_ENV_VALUES.txt`, copy toàn bộ vào Backend Service -> Environment rồi redeploy.

Frontend chỉ có:

```env
VITE_JITSI_SERVER_URL=https://42.96.12.227
```

Không đặt secret vào web hoặc Flutter.

## Nếu đã đổi access/refresh secret

Web:

```javascript
localStorage.clear();
sessionStorage.clear();
location.href = '/login';
```

Flutter:

```powershell
adb shell pm clear com.example.flutter_application_1
```

Sau đó đăng nhập lại.

## Chạy lại

```powershell
cd D:\fullweb\web_v89_full\web_v89_full_FIXED
npm run dev
```

```powershell
cd D:\bank\meetmobile\flutter_application_1
flutter run
```
